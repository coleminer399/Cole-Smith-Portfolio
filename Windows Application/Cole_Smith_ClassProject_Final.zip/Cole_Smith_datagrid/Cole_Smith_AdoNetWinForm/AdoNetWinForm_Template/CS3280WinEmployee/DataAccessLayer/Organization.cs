﻿using System;

namespace DataAccessLayer
{


    partial class Organization
    {
        partial class EmployeesDataTable
        {
        }
    }
}


